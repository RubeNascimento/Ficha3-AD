public class characterUtilities {
    public static char lowerLetterSuccessorOf (char caractere){
        if (caractere == 'z'){
            return 'a';
        }
        else {
            int code = (int) caractere;
            code++;
            return (char) code;
        }
    }
    public static char lowerLetterPredecessorOf (char caractere){
        if (caractere == 'a'){
            return 'z';
        }
        else {
            int code = (int) caractere;
            code--;
            return (char) code;
        }
    }
    public static char lowerLetterSuccessorStepsOf (char caractere, int quantidade){
        int originalAlphabetPosition = caractere - 'a';
        int newAlphabetPosition = (originalAlphabetPosition + quantidade) % 26;
        return (char) ('a' + newAlphabetPosition);
    }
    public static char lowerLetterPredecessorStepsOf (char caractere, int quantidade){
        int originalAlphabetPosition = caractere - 'a';
        int newAlphabetPosition = (originalAlphabetPosition - quantidade) % 26;
        if (newAlphabetPosition < 0)
                newAlphabetPosition += 26;
        return (char) ('a' + newAlphabetPosition);
    }
    public static int occurrencesOfCharacterIn (char[] array, char letra){
        int contaCaractere = 0;
        for (int i = 0; i< array.length; i++){
            if (array[i] == letra){
                contaCaractere++;
            }
        }
        return contaCaractere;
    }
    public static char[] replaceCharacterIn (char[] array, char substituir, char novoCaractere){
        for (int i = 0; i< array.length; i++){
            if (array[i] == substituir){
                array[i] = novoCaractere;
            }
        }
        return array;
    }
    public static char[] concatenationOf (char[] array1, char[] array2){
        char[] arrayFinal = new char[array1.length + array2.length];
        for (int i =0; i < array1.length; i++){
            arrayFinal[i] =array1[i];
        }
        for (int i =0; i< array2.length; i++){
            arrayFinal[i + array1.length] = array2[i];
        }
        return arrayFinal;
    }
    public static char[] copyOfPartOf (char[] array, int indiceInicial, int indiceFinal){
        if (indiceFinal < indiceInicial)
            throw new IllegalArgumentException("O valor inicial é maior do que o valor final.");
        char[] arrayFinal = new char[indiceFinal - indiceInicial + 1];
        for (int i = 0; i < indiceFinal-indiceInicial+1; i++){
            arrayFinal[i] = array[indiceInicial+i];
        }
        return arrayFinal;
    }
    public static String cipher (String original, int offset){
        String ciphered = new String();
        for (int i=0; i< original.length(); i++) {
            if ((int) original.charAt(i) == 32)
                ciphered += " ";
            else {
                int originalAlphabetPosition = original.charAt(i) - 'a';
                int newAlphabetPosition = (originalAlphabetPosition + offset) % 26;
                ciphered += (char) ('a' + newAlphabetPosition);
            }
        }
        return ciphered;
    }
}
