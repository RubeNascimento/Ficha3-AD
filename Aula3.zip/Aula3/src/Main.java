import java.util.Arrays;

public class Main {
    public static void main(String[] args){
        char resultlowerLetterSuccessorOf = characterUtilities.lowerLetterSuccessorOf('f');
        System.out.println("A letra seguinte é: " + resultlowerLetterSuccessorOf);
        char resultlowerLetterPredecessorOf = characterUtilities.lowerLetterPredecessorOf('f');
        System.out.println("A letra anterior é: "+ resultlowerLetterPredecessorOf);
        char resultlowerLetterSuccessorStepsOf = characterUtilities.lowerLetterSuccessorStepsOf('f',231);
        System.out.println("A letra final é: " + resultlowerLetterSuccessorStepsOf);
        char resultlowerLetterPredecessorStepsOf = characterUtilities.lowerLetterPredecessorStepsOf('f',231);
        System.out.println("A letra final é: " + resultlowerLetterPredecessorStepsOf);
        char[] array = {'a','w','c','w','b','v','w'};
        char[] array1 = {'a','w','c','w','b','v','w'};
        char[] array2 = {'z','a','c'};
        int resultoccurrencesOfCharacterIn = characterUtilities.occurrencesOfCharacterIn(array,'w');
        System.out.println("A letra aparece " + resultoccurrencesOfCharacterIn + " vezes.");
        char[] resultreplaceCharacterIn = characterUtilities.replaceCharacterIn(array, 'w','r');
        System.out.println("O array substituído é " + Arrays.toString(resultreplaceCharacterIn));
        char[] resultconcatenationOf = characterUtilities.concatenationOf(array1, array2);
        System.out.println("O array concatenado é: " + Arrays.toString(resultconcatenationOf));
        char[] resultcopyOfPartOf = characterUtilities.copyOfPartOf(array,3,6);
        System.out.println("A seleção escolhida é: " + Arrays.toString(resultcopyOfPartOf));


    }
}
